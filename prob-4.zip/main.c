#include <stdio.h>
int main()
{
    float temp[24],s= 0, avg,min,max;
    int i;
    int maxHour = 0, minHour = 0;
    printf("Enter 24 temperature readings:\n");
    for(i = 0; i < 24; i++)
    {
        scanf("%f", &temp[i]);
        s = s + temp[i];
    }
    max = temp[0];
    min = temp[0];
    for(i = 1; i < 24; i++)
    {
        if(temp[i] > max)
        {
            max = temp[i];
            maxHour = i;
        }
        if(temp[i] < min)
        {
            min = temp[i];
            minHour = i;
        }
    }
    avg = s / 24;
    printf("\nMaximum Temperature = %.2f at hour %d\n",max,maxHour);
    printf("Minimum Temperature = %.2f at hour %d\n",min,minHour);
    printf("Average Temperature = %.2f\n",avg);
    if(avg > 35)
        printf("Condition : HOT\n");
    else if(avg >= 20)
        printf("Condition : NORMAL\n");
    else
        printf("Condition
        : COLD\n");
    return 0;
}