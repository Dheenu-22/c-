#include <stdio.h>

int main() {
    float h, daily, total = 0;
    float rate = 100;
    int i;
    printf("Payroll Summary\n");
    printf("Day   Hours\n");
    for(i = 1; i <= 7; i++) {
        printf("%2d     ", i);
        scanf("%f", &h);
        if(h <= 8)
            daily = h * rate;
        else
            daily = 8 * rate + (h - 8) * rate * 2;

        printf("%5.1f  %7.2f\n", h, daily);
        total += daily;
    }
    printf("-------------------------------\n");
    printf("Total Weekly Salary: %.2f\n", total);

    return 0;
}
