#include <stdio.h>
int main()
{
    float a,b,c,d,e,f,sum,per;
    int m=0,n=0,o=0,p=0;
    scanf("%f %f %f %f %f %f",&a,&b,&c,&d,&e,&f);
    sum=a+b+c+d+e+f;
    per=(a+b+c+d+e+f)/6;
    if(sum>90)
    printf("Excellent");
    else if(sum>=75&&sum<=90)
    printf("Very good");
    else if(sum<75&&sum>=50)
    printf("Good");
    else if(sum<50)
    printf("Need improvement");
    if(a>90)
    m++;
    else if(a>=75&&a<=90)
    n++;
    else if(a<75&&a>=50)
    o++;
    else if(a<50)
    p++;
    if(b>90)
    m++;
    else if(b>=75&&b<=90)
    n++;
    else if(b<75&&b>=50)
    o++;
    else if(b<50)
    p++;
     if(c>90)
    m++;
    else if(c>=75&&c<=90)
    n++;
    else if(c<75&&c>=50)
    o++;
    else if(c<50)
    p++;
     if(d>90)
    m++;
    else if(d>=75&&d<=90)
    n++;
    else if(d<75&&d>=50)
    o++;
    else if(d<50)
    p++;
     if(e>90)
    m++;
    else if(e>=75&&e<=90)
    n++;
    else if(e<75&&e>=50)
    o++;
    else if(e<50)
    p++;
     if(f>90)
    m++;
    else if(f>=75&&f<=90)
    n++;
    else if(f<75&&f>=50)
    o++;
    else if(f<50)
    p++;
    printf("\nTotal=%.1f\n",sum);
    printf("Percentage=%.1f\n",per);
    printf("Excelence=%d\n",m);
    printf("very good =%d\n",n);
    printf("good =%d\n",o);
    printf("average=%d\n",p);
    
    return 0;
}